#include "level4.h"


int Level4::getLevelNumber() const {
	return 4;
}


Level4::Level4(int seed, bool isRandom)
: Level3{seed, isRandom} {}


