#ifndef CELL_DATA_H
#define CELL_DATA_H

#include "pos.h"

struct CellData {
	char blockType; // Change to enum?
	Pos position;
};

#endif


