#ifndef SCOREBOARDDATA_H
#define SCOREBOARDDATA_H

struct ScoreBoardData {
	int level;
	int currentScore;
	int hiScore;
	char nextBlockLetter;
	bool gameOver;
};


#endif

